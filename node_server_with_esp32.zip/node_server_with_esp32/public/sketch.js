var socket; //adding socket
let inMessage = "";

function setup() {
    createCanvas(400,400);
    noStroke();
    background(255);
    fill(0);
    socket = new WebSocket('http://localhost:8080');

    
    socket.onmessage = function (event) {
        inMessage = event.data.text();
        inMessage.then(value => {
            inMessage = value;
          });
    }
}

function draw() {
    background(0);
    console.log(inMessage);
}

function mousePressed(){
    socket.send("test");
}