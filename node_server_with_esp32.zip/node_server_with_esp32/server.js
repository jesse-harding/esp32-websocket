//terminal:
    // navigate to project folder (cd & drag from finder)
    // npm install node
    // npm install express
    // npm install socket.io //make sure versions match between server and client
    // node server.js to run server
//make folder named "public" in project dir for hosted site

const path = require('path');
var express = require('express');			// include express.js
var app = express();
const filePath = path.join(__dirname, 'public');
app.use("/", express.static(filePath));

var WebSocketServer = require('ws').Server	// include Web Socket server
// let prevMessage = '';

// this runs after the server successfully starts:
function serverStart() {

	var port = server.address().port;
	console.log('Server listening on port '+ port);
}

// start the server:
var server = app.listen(8080, serverStart);

// create a WebSocket server and attach it to the server
var wss = new WebSocketServer({server: server});

wss.on('connection', function connection(ws) {
	console.log("connection");
	// new connection, add message listener
	ws.on('message', function incoming(message) {
		// received a message
		// if (message != prevMessage){
		console.log('received: %s', message);
		// echo it back
		//    ws.send(message); //sends just back to one client
		   wss.clients.forEach(client => client.send(message));
		// }
		// prevMessage = message;

	});
});